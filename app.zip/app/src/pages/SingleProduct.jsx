import React from 'react'

const SingleProduct = () => {
  return (
    <div>SingleProduct</div>
  )
}

export default SingleProduct